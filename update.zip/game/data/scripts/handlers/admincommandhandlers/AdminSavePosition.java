/*
 * Copyright (c) 2013 L2jMobius
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package handlers.admincommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.logging.Logger;

import org.l2jmobius.commons.database.DatabaseFactory;
import org.l2jmobius.gameserver.handler.IAdminCommandHandler;
import org.l2jmobius.gameserver.model.actor.Player;

/**
 * @author sskim
 */
public class AdminSavePosition implements IAdminCommandHandler
{
	private static final Logger LOGGER = Logger.getLogger(AdminSavePosition.class.getName());
	
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_savepos" // 명령어 추가
	};
	
	@Override
	public boolean useAdminCommand(String command, Player player)
	{
		if (command.equals("admin_savepos"))
		{
			savePosition(player);
			player.sendMessage("현재 좌표가 디비에 저장되엇습니다.");
		}
		return true;
	}
	
	private void savePosition(Player player)
	{
		final String sql = "REPLACE INTO saved_positions (charId, x, y, z) VALUES (?, ?, ?, ?)";
		
		try (Connection con = DatabaseFactory.getConnection();
			PreparedStatement ps = con.prepareStatement(sql))
		{
			ps.setInt(1, player.getObjectId());
			ps.setInt(2, player.getX());
			ps.setInt(3, player.getY());
			ps.setInt(4, player.getZ());
			ps.executeUpdate();
			LOGGER.info("좌표 저장됨: " + player.getName() + " (X: " + player.getX() + ", Y: " + player.getY() + ", Z: " + player.getZ() + ")");
		}
		catch (Exception e)
		{
			LOGGER.warning("좌표 저장 중 오류 발생: " + e.getMessage());
		}
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
	
}
