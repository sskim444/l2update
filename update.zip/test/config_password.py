import os
import chardet
import fileinput

# DB 비밀번호를 변경한다.
newline = 'Password = 1234' # 변경할 비밀번호를 적으세요.

gamepath = './game/config/Server.ini'
loginpath = './login/config/LoginServer.ini'
start_word = 'Password = ' # 찾을 줄의 시작점

# 딕셔너리 인코딩의 키값을 반환
def return_encoding(filepath):
    with open(filepath, 'rb') as f:
        result = chardet.detect(f.read())['encoding']

        # ASCII 또는 인코딩을 감지하지 못한 경우 UTF-8로 설정
        if result is None or result.lower() == 'ascii':
            result = 'utf-8'

        print(filepath, '인코딩값: ', result)
        return result

# 특정 단어로 시작되는 라인을 변경한다.
def change_line(filepath, start_word, newline):
    cnt = 0     # 변경된 횟수
    linenum = [] # 변경된 줄 번호 리스트
    encoding = return_encoding(filepath)

    with fileinput.input(filepath, inplace=True, encoding=encoding, errors='replace') as f:
        for line in f:
            if line.startswith(start_word):     # start_word로 시작되는 라인이 있으면
                print(newline, end='\n')        # newline으로 변경한다.
                cnt += 1
                linenum.append(f.filelineno())  # 변경된 줄 번호를 구해서 리스트에 추가
            else:
                print(line, end='')

    print(f'[{start_word}]를 [{newline}]으로 {cnt}회 변경했습니다.')
    print('변경된 줄 번호: ', linenum, end='\n\n')

change_line(gamepath, start_word, newline)
change_line(loginpath, start_word, newline)

# 멈추는 현상때문에 더블클릭해서 실행할때만 정지하게..
is_vim = 'VIM' in os.environ
if not is_vim:
    input("엔터 누르면 종료...Press Enter to exit...")
